# CSCI3170 Project
# ------------------------ 
# Group 1
# ------------------------ 
# Group Members:
# Suen Ka Leong 1155062592
# Mok Yat Man 1155078128
# So Hon Chuen 1155062753
# ------------------------
# Compile and Run Script

javac RideSharingSystem.java
java -cp .:mysql-connector-java-5.1.47.jar RideSharingSystem

# ------------------------
